package com.vogella.android.bgp;

public interface Constants {

	public static final int WORKING_DELAY = 6000; 
	
}
