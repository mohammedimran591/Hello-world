package com.vogella.android.imagegrid;

public interface Constants {
	String LOG= "com.vogella.android.imagegrid";
}
